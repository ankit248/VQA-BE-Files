Annotation Format:

[
	{
		"answer_type": "unanswerable",
		"answerable": 0,
		"answers": 
		[
			{"answer": "unsuitable", 	"answer_confidence": "yes"},
			{"answer": "unsuitable", 	"answer_confidence": "yes"},
			{"answer": "beans", 		"answer_confidence": "maybe"},
			{"answer": "unanswerable", 	"answer_confidence": "yes"},
			{"answer": "unsuitable", 	"answer_confidence": "yes"},
			{"answer": "unanswerable", 	"answer_confidence": "yes"},
			{"answer": "unanswerable", 	"answer_confidence": "maybe"},
			{"answer": "unsuitable", 	"answer_confidence": "yes"},
			{"answer": "unanswerable", 	"answer_confidence": "yes"},
			{"answer": "unsuitable", 	"answer_confidence": "maybe"}
		],
		"image": "VizWiz_val_000000028000.jpg",
		"question": "What's this?"
	}
	,
	...
]

